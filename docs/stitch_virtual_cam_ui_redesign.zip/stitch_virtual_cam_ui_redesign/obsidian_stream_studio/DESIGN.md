---
name: Obsidian Stream Studio
colors:
  surface: '#0f131d'
  surface-dim: '#0f131d'
  surface-bright: '#353944'
  surface-container-lowest: '#0a0e18'
  surface-container-low: '#171b26'
  surface-container: '#1c1f2a'
  surface-container-high: '#262a35'
  surface-container-highest: '#313540'
  on-surface: '#dfe2f1'
  on-surface-variant: '#c2c6d6'
  inverse-surface: '#dfe2f1'
  inverse-on-surface: '#2c303b'
  outline: '#8c909f'
  outline-variant: '#424754'
  surface-tint: '#adc6ff'
  primary: '#adc6ff'
  on-primary: '#002e6a'
  primary-container: '#4d8eff'
  on-primary-container: '#00285d'
  inverse-primary: '#005ac2'
  secondary: '#4edea3'
  on-secondary: '#003824'
  secondary-container: '#00a572'
  on-secondary-container: '#00311f'
  tertiary: '#4cd7f6'
  on-tertiary: '#003640'
  tertiary-container: '#009eb9'
  on-tertiary-container: '#002f38'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc6ff'
  on-primary-fixed: '#001a42'
  on-primary-fixed-variant: '#004395'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#acedff'
  tertiary-fixed-dim: '#4cd7f6'
  on-tertiary-fixed: '#001f26'
  on-tertiary-fixed-variant: '#004e5c'
  background: '#0f131d'
  on-background: '#dfe2f1'
  surface-variant: '#313540'
typography:
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 1.75rem
    fontWeight: '700'
    lineHeight: 2.25rem
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 1.375rem
    fontWeight: '700'
    lineHeight: 1.75rem
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.625rem
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 1rem
    fontWeight: '600'
    lineHeight: 1.375rem
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.9375rem
    fontWeight: '400'
    lineHeight: 1.375rem
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.25rem
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1rem
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.8125rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.6875rem
    fontWeight: '700'
    lineHeight: 0.875rem
    letterSpacing: 0.04em
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: 1.125rem
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.875rem
  space-lg: 1.25rem
  space-xl: 1.75rem
---

## Brand & Style

This design system powers a high-performance streaming, low-latency capture, and virtual webcam ecosystem bridging mobile video hardware to desktop studio environments. The aesthetic sits at the intersection of technical pro-audio/video hardware and modern aerospace telemetry interfaces: focused, non-distracting, dark-mode exclusive, and ultra-ergonomic for low-light recording environments.

The visual direction combines **deep slate minimalism** with **refined glassmorphism**:
- Deep obsidian and charcoal backdrops (#080C14, #0F172A) eliminate visual fatigue and keep focus strictly on camera feeds and telemetry.
- Sub-pixel borders (`rgba(255, 255, 255, 0.08)`) and muted surfaces replace heavy drop shadows.
- Vivid status neon indicators—emerald for active capture/low-latency links and electric blue for primary interactive triggers—provide instantaneous recognition from across the room.
- Turkish studio terminology is preserved natively across both platforms for operational consistency.

## Colors

The system uses a strictly controlled dark hierarchy tailored for media production suites:

- **Primary Canvas & Surfaces**:
  - `bg-canvas`: `#080C14` (Deepest navy black for viewports and screen backgrounds).
  - `surface-base`: `#0F172A` (Card backs, panel bodies).
  - `surface-elevated`: `#1E293B` (Inputs, inactive toggle buttons, telemetry cells).
  - `surface-hover`: `#283548` (Interactive hover state).
  - `border-subtle`: `rgba(255, 255, 255, 0.08)` (Crisp 1px card separators).
  - `border-active`: `rgba(59, 130, 246, 0.5)` (Focused inputs and active tabs).

- **Action & Accent Roles**:
  - `brand-accent` (`#3B82F6` / `#6366F1`): Primary actions such as *Ayarları Telefona Gönder Uygula* and active selector pills.
  - `status-live` (`#10B981`): Active streaming, healthy connection, and primary launch triggers (*YAYINI BAŞLAT*, *USB ile Bağlan*).
  - `status-standby` (`#64748B` / `#334155`): Neutral standby state (*BEKLEMEDE*).
  - `status-danger` (`#EF4444`): Disconnected or disabled states (*ÇEVRİMDIŞI*, *Kamerayı Karart*).
  - `status-cyan` (`#06B6D4`): Monospaced address and telemetry indicators (IP, port, ADB routes).

- **Typography & Content Hierarchy**:
  - `text-primary`: `#F8FAFC` (100% white-slate for titles, values, and high-priority labels).
  - `text-secondary`: `#94A3B8` (Muted slate for field descriptions, inactive tabs).
  - `text-tertiary`: `#64748B` (De-emphasized technical hints).

## Typography

The typography system uses three purposeful typefaces:
1. **Space Grotesk**: Provides a clean, modern studio aesthetic for the primary logo *AselCam*, module headers (*Ayrıntılı Kalite & Akış Ayarları*), and panel groupings.
2. **Plus Jakarta Sans**: Delivers high legibility at micro sizes across buttons, segment chips (*1080p Yatay (16:9)*), and property titles under dim lighting.
3. **JetBrains Mono**: Used for real-time telemetry, IP/port pairings (`192.168.1.3`, `adb forward tcp:4747`), bitrates, battery indicators, and kernel module labels.

All status badges (*BEKLEMEDE*, *ÇEVRİMDIŞI*) use uppercase styling with slight letter-spacing (`0.04em`) to ensure instant state identification.

## Layout & Spacing

The UI employs a rigid 4px/8px modular spacing scale to maintain operational density without clutter:

- **Desktop Layout**:
  - Top persistent bar (48px height) for brand identity, global connection state, latency telemetry, and battery status.
  - Two-pane workspace: A 16:9 responsive viewport canvas taking 65–70% width, paired with a tabbed control inspector panel on the right (30–35% width, min 380px).
  - Bottom master strip (44px) housing quick hardware toggles (*Önizlemeyi Kapat*, *Kamerayı Karart*, *Mikrofonu Kapat*), master audio slider, and virtual driver diagnostics.

- **Mobile Layout**:
  - Vertical stack with a fixed header displaying *AselCam* and the standby badge.
  - Top preview module with hardware control quick-actions (*Kamera Değiştir*, *Flaş*, *Önizleme*, *Güç*).
  - Full-width call-to-action button (*YAYINI BAŞLAT*).
  - Scrolling configuration cards with 12px gaps between panels.

- **Grid & Alignment**: Horizontal button grids (e.g. FPS: 60, 30, 24, 15) must always share equal column distribution via flexible CSS grids (`grid-template-columns: repeat(auto-fit, minmax(0, 1fr))`).

## Elevation & Depth

Visual hierarchy relies on backdrop contrast, luminescence, and precision outlines rather than soft, elevated shadows:

- **Level 0 (Canvas Base)**: `#080C14` solid background.
- **Level 1 (Card & Section Containers)**: `#0F172A` with a 1px border of `rgba(255, 255, 255, 0.08)`. High-priority cards (like the live preview area) feature an inner inset border of `rgba(0, 0, 0, 0.4)`.
- **Level 2 (Pills, Fields & Interactive Cells)**: `#1E293B` background. Inactive chips use a hairline outline of `rgba(255, 255, 255, 0.05)`. Active items elevate through color fills (`#3B82F6` or `#10B981`) combined with a localized glow: `0 0 16px rgba(59, 130, 246, 0.35)`.
- **Level 3 (Modals & Floating HUDs)**: `#111827` overlaid with `backdrop-filter: blur(12px)` and a subtle ambient ring: `0 8px 32px rgba(0, 0, 0, 0.6)`.

## Shapes

The design uses a balanced rounded architecture (radius scale `2` = base 8px / 0.5rem):

- **Panels & Shell Containers**: 12px (`0.75rem`) to 16px (`1rem`) corner radius for modular containment.
- **Buttons, Selection Chips & Inputs**: 8px (`0.5rem`) corner radius to deliver a precise, tactile feel without feeling toy-like.
- **Status Pills & Live Tags**: Full rounded pill (`9999px`) for quick-glance status elements (*BEKLEMEDE*, *ÇEVRİMDIŞI*, battery pills).
- **Slider Handles & Knobs**: Circular geometry with a dual-ring border for precise cursor and touch grab targets.

## Components

### Buttons
- **Primary Live / Connect Action** (*YAYINI BAŞLAT*, *USB ile Bağlan*):
  - Background: Emerald gradient `linear-gradient(135deg, #10B981 0%, #059669 100%)`.
  - Text: Bold `#FFFFFF`, centered icon + text, height 44px (mobile: 48px touch target).
  - Hover / Active: Scale 0.99, glow `0 0 20px rgba(16, 185, 129, 0.4)`.
- **Primary Control Action** (*Ön / Arka Kamera Değiştir*, *Ayarları Telefona Gönder*):
  - Background: Electric Blue `linear-gradient(135deg, #3B82F6 0%, #2563EB 100%)`.
  - Text: `#FFFFFF`, height 40px, font weight 600.
- **Secondary / Utility Buttons** (*Önizlemeyi Kapat*, *Kamerayı Karart*, *Filtreleri Sıfırla*):
  - Background: `#1E293B`, border: 1px solid `rgba(255, 255, 255, 0.08)`.
  - Text: `#94A3B8`. Hover: Background `#273549`, Text: `#F8FAFC`.

### Selection Chips & Grids (Resolution, FPS, Codec)
- Layout: Multi-column grid (`gap: 0.5rem`).
- **Inactive State**: `#1E293B`, border: 1px solid `rgba(255, 255, 255, 0.05)`, text: `#94A3B8`.
- **Active State**: Deep slate-blue tint `#334155` or primary `#3B82F6`, border: 1px solid `#60A5FA`, text: `#FFFFFF`, font weight 600.

### Sliders (Bitrate, Zoom, Audio, Contrast, Saturation)
- Track: 6px height, background `#1E293B`, filled portion: `#3B82F6` (or emerald for signal strength).
- Thumb: 18px circle, background `#FFFFFF`, border: 3px solid `#3B82F6`, shadow `0 2px 8px rgba(0,0,0,0.5)`.
- Numeric readout aligned flush right above the track in `JetBrains Mono` (`100%`, `4 Mbps`, `1.0x`).

### Status Badges & Pills
- **Standby** (*BEKLEMEDE*): Background `rgba(100, 116, 139, 0.2)`, border `rgba(148, 163, 184, 0.3)`, text `#CBD5E1`.
- **Offline** (*ÇEVRİMDIŞI*): Background `rgba(239, 68, 68, 0.15)`, border `rgba(239, 68, 68, 0.4)`, text `#F87171` with blinking red status pip.
- **Online / Streaming**: Background `rgba(16, 185, 129, 0.15)`, border `rgba(16, 185, 129, 0.4)`, text `#34D399`.

### Text Inputs & Form Fields
- Background: `#0B0F19`, border: 1px solid `rgba(255, 255, 255, 0.1)`.
- Height: 38px, padding: `0 12px`, typography: `Plus Jakarta Sans` or `JetBrains Mono` for addresses.
- Focus: Border `#3B82F6`, box-shadow `0 0 0 2px rgba(59, 130, 246, 0.2)`.

### Viewport Blank Slate / Offline Monitor
- Centered iconography (`eye-off` / `video-off`) in `#475569`.
- Primary label: `Önizleme Devre Dışı` or `Kamera akışı bekleniyor...`.
- Helper line: `GPU & Ekran gücünden tasarruf ediliyor. Yayın devam ediyor.` in `#64748B`.